package com.virtusa.microcoder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicrocoderApplicationTests {

	@Test
	void contextLoads() {
	}

}
