package com.virtusa.microcoder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicrocoderApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicrocoderApplication.class, args);
	}

}
